<p align="center">
  <a href="https://v2.nonebot.dev/"><img src="https://zsy.juncikeji.xyz/i/img/mxy.png" width="150" height="150" alt="API管理系统"></a>
</p>
<div align="center">
    <h1 align="center">✨萌新源API管理系统</h1>
</div>
<p align="center">
<!-- 插件名称 -->
<img src="https://img.shields.io/badge/插件名称-星座运势-blue" alt="python">
<!-- Python版本 -->
<img src="https://img.shields.io/badge/-Python3-white?style=flat-square&logo=Python">
<!-- 插件名称 -->
<img src="https://img.shields.io/badge/Python-3.8+-blue" alt="python">
<a href="https://blog.juncikeji.xyz">
<img src="https://img.shields.io/badge/博客-萌新源-red">
</a>
</p>

# 使用教程

## 命令：#星座 + 想要查询的星座
